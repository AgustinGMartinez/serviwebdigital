<?php require('header.php'); ?>
<section class="videoSection">

  <div class="videoContainer">

    <video width="100%" height="100%" autoplay loop muted>
      <source src="../img/working-vid.mp4" type="video/mp4" />
      Your browser does not support the video tag.
    </video>
    <img src="../img/us.jpg" alt="">
  </div>


  <div class="container">

    <div class="titles">

      <h1>Hacemos crecer tu negocio</h1>
      <h2>Atrayendo más clientes</h2>

    </div>

  </div>

</section>

<h2>Explora algunos de los increíbles sitios que hicimos.</h2>

<script type="text/javascript">
  var pageName = "us.php";
</script>
<?php require('footer.php'); ?>
