<?php require("header.php"); ?>
<h1 style="text-align: center; margin: 5em auto; display: block;">Soon &copy</h1>
<?php require("footer.php"); ?>
